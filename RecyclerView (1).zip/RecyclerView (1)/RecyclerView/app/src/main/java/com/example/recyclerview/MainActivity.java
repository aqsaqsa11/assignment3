package com.example.recyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private List<ContactClass> data;
    private RecyclerView rv;
    private Adapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        rv = findViewById(R.id.my_recycler_view);
        rv.setHasFixedSize(true);
        rv.setLayoutManager(new LinearLayoutManager(this));

        data = new ArrayList<ContactClass>();

        getData();
    }


    void getData(){
        ContactClass cc;
        String image1 = "https://www.pngitem.com/pimgs/m/35-350426_profile-icon-png-default-profile-picture-png-transparent.png";
        String image2 = "https://i.ya-webdesign.com/images/default-image-png-4.png";
        String image3 = "https://i.ya-webdesign.com/images/default-avatar-png-9.png";
        String image4 = "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcT6wwAJhnlzLGiOOgtdv3LzMfmEVDCvURYqQA&usqp=CAU";

        List<String> imgUrl = new ArrayList<>();

        imgUrl.add(image1);
        imgUrl.add(image2);
        imgUrl.add(image3);
        imgUrl.add(image4);

        for (int i=0; i<10; i++){
            int n = i+1;
            String image = getImage(imgUrl);
            cc = new ContactClass("Menu Item "+n,"+92 312 345678"+n,"abc@xyz.com",image);
            data.add(cc);
        }

        adapter = new Adapter(data, MainActivity.this);
        rv.setAdapter(adapter);



    }

    String getImage(List<String> data){
        Random rand = new Random();
        int numberOfElements = 4;
        String randomElement = "";

        for (int i = 0; i < numberOfElements; i++) {
            int randomIndex = rand.nextInt(data.size());
            randomElement = data.get(randomIndex);
        }
        return randomElement;
    }

}
