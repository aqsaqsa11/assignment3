package com.example.recyclerview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class ContactDetail extends AppCompatActivity {

    CircleImageView image, image1;
    TextView name, email, number;

    String iName, iEmail, iNumber, iImage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_detail);

        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        number = findViewById(R.id.number);

        image = findViewById(R.id.contactImage);
        image1 = findViewById(R.id.image);


        iName = getIntent().getExtras().getString("name");
        iEmail = getIntent().getExtras().getString("email");
        iNumber = getIntent().getExtras().getString("contact");
        iImage = getIntent().getExtras().getString("image");

        name.setText(iName);
        email.setText(iEmail);
        number.setText(iNumber);

        Glide.with(ContactDetail.this).load(iImage).centerCrop().into(image);
        Glide.with(ContactDetail.this).load(iImage).centerCrop().into(image1);


    }
}
