package com.example.recyclerview;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.squareup.picasso.Picasso;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class Adapter extends RecyclerView.Adapter<Adapter.viewHolder>{

    private List<ContactClass> data;
    Context mCtx;

    public Adapter(List<ContactClass> data, Context mCtx) {
        this.data = data;
        this.mCtx = mCtx;
    }

    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.model_contacts,parent,false);
        return new viewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, final int position) {
        holder.name.setText(data.get(position).getName());

//        Picasso.get().load(data.get(position).getImage()).into(holder.image);

        Glide.with(mCtx).load(data.get(position).getImage()).centerCrop().into(holder.image);




        holder.mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent = new Intent(mCtx, ContactDetail.class);
                intent.putExtra("name",data.get(position).getName());
                intent.putExtra("email",data.get(position).getEmail());
                intent.putExtra("contact",data.get(position).getNumber());
                intent.putExtra("image",data.get(position).getImage());

                mCtx.startActivity(intent);

            }
        });

    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    class viewHolder extends RecyclerView.ViewHolder{
        CircleImageView image;
        TextView name;
        LinearLayout mainLayout;


        public viewHolder(@NonNull View itemView) {
            super(itemView);

            image = itemView.findViewById(R.id.image);
            name = itemView.findViewById(R.id.name);

            mainLayout = itemView.findViewById(R.id.mainLayout);

        }
    }

}
